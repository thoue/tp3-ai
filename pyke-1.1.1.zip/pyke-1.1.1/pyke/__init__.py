# $Id: __init__.py cb952835bf06 2010-04-26 mtnyogi $

version = '1.1.1'

compiler_version = 1

target_pkg_version = 1
